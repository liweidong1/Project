//
//  ListCell.m
//  项目
//
//  Created by liweidong on 17/8/1.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "ListCell.h"

@implementation ListCell

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self setUI];
    }
    return self;
}
-(void)setUI
{
    [self iv];
    [self contentLab];
}
- (UIImageView *)iv {
    if(_iv == nil) {
        _iv = [[UIImageView alloc] init];
        [self.contentView addSubview:_iv];
        [_iv mas_makeConstraints:^(MASConstraintMaker *make) {
            //1242 *1016
            make.top.equalTo(0);
            make.left.equalTo(20);
            make.right.equalTo(-20);
            make.height.equalTo((kScreenW-40)*1016/1242);
        }];
    }
    return _iv;
}

- (UILabel *)contentLab {
    if(_contentLab == nil) {
        _contentLab = [[UILabel alloc] init];
        _contentLab.numberOfLines = 0;
        _contentLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_contentLab];
        [_contentLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(20);
            make.right.equalTo(-20);
            make.top.equalTo(self.iv.mas_bottom).equalTo(0);
        }];
    }
    return _contentLab;
}
@end
