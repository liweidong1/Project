//
//  ListViewController.m
//  项目
//
//  Created by liweidong on 17/8/1.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "ListViewController.h"
#import "ListCell.h"
@interface ListViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;


@property(nonatomic,strong)ListCell *cell;

@property(nonatomic,strong)NSArray *contentArr;

@end

@implementation ListViewController
static NSString * const reuseIdentifier = @"Cell";
- (NSArray *)contentArr {
    if(_contentArr == nil) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"content" ofType:@"plist"];
        _contentArr =  [NSArray arrayWithContentsOfFile:path];
    }
    return _contentArr;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [LFactory addBackItemForVC:self isPush:YES];
    
    [self contentArr];
    
    [self setTableView];
}



-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.bounds];
    self.tableView.backgroundColor = LWDColorA(234, 234, 234, 1);
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:[ListCell class] forCellReuseIdentifier:reuseIdentifier];
    
//    [self loadDatas];
    
}

#pragma UITableViewDelegate  Datasource

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _contentArr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ListCell* cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    _cell = cell;
    if (!cell) {
        cell = [[ListCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    }
    cell.iv.image = LWDImage(@"videoDefault");
    cell.contentLab.text = _contentArr[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return _cell.iv.size.height + _cell.contentLab.size.height;
}



@end
