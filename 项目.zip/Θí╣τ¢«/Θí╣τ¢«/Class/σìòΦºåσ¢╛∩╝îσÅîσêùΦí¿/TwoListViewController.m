//
//  TwoListViewController.m
//  项目
//
//  Created by liweidong on 17/8/1.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "TwoListViewController.h"

@interface TwoListViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *leftTableView;
@property(nonatomic,strong)UITableView *rightTableView;

@property(nonatomic,assign)NSInteger rightRow;
@end
static NSString * const reuseIdentifierOne = @"CellOne";
static NSString * const reuseIdentifierTwo = @"CellTwo";
@implementation TwoListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _rightRow = 5;
    self.view.backgroundColor = [UIColor whiteColor];
    [LFactory addBackItemForVC:self isPush:YES];
    [self setTableView];
}



-(void)setTableView
{
    CGRect rect = CGRectMake(0, 0, kScreenW/2, kScreenH);
    self.leftTableView = [[UITableView alloc]initWithFrame:rect];
    self.leftTableView.rowHeight = ([UIScreen mainScreen].bounds.size.width * 618/480);
    self.leftTableView.delegate = self;
    self.leftTableView.dataSource = self;
    [self.view addSubview:self.leftTableView];
    [self.leftTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:reuseIdentifierOne];
    
    
    CGRect rectTwo = CGRectMake(kScreenW/2, 64, kScreenW/2, kScreenH);
    self.rightTableView = [[UITableView alloc]initWithFrame:rectTwo];
    self.rightTableView.rowHeight = ([UIScreen mainScreen].bounds.size.width * 618/480);
    self.rightTableView.delegate = self;
    self.rightTableView.dataSource = self;
    [self.view addSubview:self.rightTableView];
    [self.rightTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:reuseIdentifierTwo];
    
    
}

#pragma UITableViewDelegate  Datasource

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
//    return 8;
    if (tableView == self.leftTableView) {
        return 8;
    }else{
        return _rightRow;
    }
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    if (tableView == self.leftTableView) {
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierOne];
        cell.textLabel.text = @"one";
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;

    }else{
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierTwo];
        cell.textLabel.text = @"two";
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (tableView == _leftTableView) {
        if (indexPath.row == 0) {
            _rightRow = 5;
        }else if(indexPath.row == 1){
            _rightRow = 2;
        }else if(indexPath.row == 2){
            _rightRow = 3;
        }else if(indexPath.row == 2){
            _rightRow = 4;
        }else if(indexPath.row == 3){
            _rightRow = 10;
        }else if(indexPath.row == 4){
            _rightRow = 6;
        }else if(indexPath.row == 5){
            _rightRow = 7;
        }else if(indexPath.row == 6){
            _rightRow = 9;
        }else{
            _rightRow = 3;
        }
        [self.rightTableView reloadData];
    }
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

@end
