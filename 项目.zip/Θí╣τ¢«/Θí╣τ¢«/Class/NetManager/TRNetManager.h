//
//  TRNetManager.h
//  GameLive
//
//  Created by tarena on 16/8/1.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "BaseNetworking.h"



#import "TRIntroModel.h"
#import "BeautyModel.h"



@interface TRNetManager : BaseNetworking
//轮播图
+ (id)getIntroCompletionHandler:(void(^)(TRIntroModel *model, NSError *error))completionHandler;

//瀑布流
+ (id)getBeauty:(NSInteger)page completionHandler:(void(^)(BeautyModel *model, NSError *error))completionHandler;

@end
