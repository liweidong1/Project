//
//  TRNetManager.m
//  GameLive
//
//  Created by tarena on 16/8/1.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "TRNetManager.h"

@implementation TRNetManager

+ (id)getIntroCompletionHandler:(void (^)(TRIntroModel *, NSError *))completionHandler{
    return [self GET:lIntroPath parameters:nil completionHandler:^(id responseObj, NSError *error) {
        !completionHandler ?: completionHandler([TRIntroModel parse:responseObj], nil);
    }];
}

+ (id)getBeauty:(NSInteger)page completionHandler:(void (^)(BeautyModel *, NSError *))completionHandler{
    NSString *path = [NSString stringWithFormat:lBeautyPath, page];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        !completionHandler?:completionHandler([BeautyModel parse:responseObj], error);
    }];
}
@end
