//
//  RequestPath.h
//  GameLive
//
//  Created by tarena on 16/8/1.
//  Copyright © 2016年 tarena. All rights reserved.
//

#ifndef RequestPath_h
#define RequestPath_h

//#define kBasePath       @""


//轮播图
#define lIntroPath      @"http://www.quanmin.tv/json/page/app-index/info.json"

//瀑布流
#define lBeautyPath @"http://box.dwstatic.com/apiAlbum.php?action=l&albumsTag=beautifulWoman&p=%ld&v=77&OSType=iOS8.2&versionName=2.1.7"
#endif /* RequestPath_h */
