//
//  BeautyViewModel.m
//  TRProject
//
//  Created by tarena on 16/7/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BeautyViewModel.h"

@implementation BeautyViewModel

- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler{
    NSInteger tmpPage = 1;
    if (requestMode == RequestModeMore) {
        tmpPage = _page + 1;
    }
    self.dataTask = [TRNetManager getBeauty:tmpPage completionHandler:^(BeautyModel *model, NSError *error) {
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.dataList removeAllObjects];
            }
            [self.dataList addObjectsFromArray:model.data];
            _page = tmpPage;
        }
        !completionHandler?:completionHandler(error);
    }];
}

- (NSMutableArray<BeautyDataModel *> *)dataList{
    if (!_dataList) {
        _dataList = [NSMutableArray new];
    }
    return _dataList;
}
- (NSInteger)rowNumber{
    return self.dataList.count;
}
- (NSURL *)iconURLForRow:(NSInteger)row{
    return self.dataList[row].coverUrl.yx_URL;
}
- (CGFloat)widthForRow:(NSInteger)row{
    return self.dataList[row].coverWidth.doubleValue;
}
- (CGFloat)heightForRow:(NSInteger)row{
    return self.dataList[row].coverHeight.doubleValue;
}




@end













