//
//  BeautyViewModel.h
//  TRProject
//
//  Created by tarena on 16/7/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "TRNetManager.h"

@interface BeautyViewModel : BaseViewModel
@property (nonatomic, readonly) NSInteger rowNumber;
- (NSURL *)iconURLForRow:(NSInteger)row;

- (CGFloat)widthForRow:(NSInteger)row;
- (CGFloat)heightForRow:(NSInteger)row;

@property (nonatomic) NSInteger page;
@property (nonatomic) NSMutableArray<BeautyDataModel*> *dataList;



@end











