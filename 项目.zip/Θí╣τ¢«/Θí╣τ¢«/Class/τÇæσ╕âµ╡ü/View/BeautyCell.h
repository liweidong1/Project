//
//  BeautyCell.h
//  TRProject
//
//  Created by tarena on 16/7/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BeautyCell : UICollectionViewCell
@property (nonatomic) UIImageView *iconIV;


@end







