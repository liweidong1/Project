//
//  BeautiViewController.m
//  项目
//
//  Created by liweidong on 17/8/1.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "BeautiViewController.h"
#import "BeautyViewModel.h"
#import "BeautyCell.h"
//引入布局协议
//AppDelegate里面的layout设置
//UICollectionViewDelegateFlowLayout这个代理, 默认不会被引入. 此协议可以定义每个cell的相关情况
@interface BeautiViewController ()<CHTCollectionViewDelegateWaterfallLayout>
@property (nonatomic) BeautyViewModel *beautyVM;
@end
@implementation BeautiViewController
//列数
- (NSInteger)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout columnCountForSection:(NSInteger)section{
    return 3;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    //通过代理方法返回某个section最小行间距
    return 10;
}
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    //除非是有必要(不同section的样式不同). 否则不要用代理来设置.  代理的效率低一些.
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

//每个cell显示之前, 进行询问, 显示的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    /*CGFloat width = (long)(([UIScreen mainScreen].bounds.size.width - 3 * 10)/ 2);
     CGFloat height = width * [self.beautyVM heightForRow:indexPath.row] / [self.beautyVM widthForRow:indexPath.row];
     return CGSizeMake(width, height);*/
    //传递宽高比例即可
    return CGSizeMake([self.beautyVM widthForRow:indexPath.row], [self.beautyVM heightForRow:indexPath.row]);
}


- (BeautyViewModel *)beautyVM{
    if (!_beautyVM) {
        _beautyVM = [BeautyViewModel new];
    }
    return _beautyVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [LFactory addBackItemForVC:self isPush:YES];
    self.collectionView.backgroundColor = LWDColorA(234, 234, 234, 1);
    [self.collectionView registerClass:[BeautyCell class] forCellWithReuseIdentifier:@"Cell"];
    //当xcode对block内部属性报黄色警告, 就加weak
    self.collectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.beautyVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [self.collectionView reloadData];
            [self.collectionView.mj_header endRefreshing];
        }];
    }];
    [self.collectionView.mj_header beginRefreshing];
    self.collectionView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        
        [self.beautyVM getDataWithMode:RequestModeMore completionHandler:^(NSError *error) {
            [self.collectionView reloadData];
            [self.collectionView.mj_footer endRefreshing];
        }];
        
    }];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.beautyVM.rowNumber;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    BeautyCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    [cell.iconIV setImageWithURL:[self.beautyVM iconURLForRow:indexPath.row] placeholder:[UIImage imageNamed:@"videoDefault"]];
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
