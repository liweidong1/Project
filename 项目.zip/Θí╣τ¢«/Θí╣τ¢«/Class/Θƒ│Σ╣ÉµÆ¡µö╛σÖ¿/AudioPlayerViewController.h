//
//  ViewController.h
//  PlayMusic
//
//  Created by 王落凡 on 2016/12/28.
//  Copyright © 2016年 王落凡. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AudioPlayerViewController : UIViewController

@property(nonatomic, copy) NSURL* audioPathURL;

@end

