//
//  AudioListTableViewController.m
//  PlayMusic
//
//  Created by 王落凡 on 2017/1/3.
//  Copyright © 2017年 王落凡. All rights reserved.
//

#import "AudioListViewController.h"
#import "AudioPlayerViewController.h"

@interface AudioListViewController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic, copy) NSArray* audioPathURLs;
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSArray *musicArr;

@end
static NSString * const reuseIdentifier = @"Cell";
@implementation AudioListViewController

- (NSArray *)musicArr {
    if(_musicArr == nil) {
        _musicArr =  @[[[NSBundle mainBundle] URLForResource:@"遥远的她" withExtension:@"mp3"],
                       [[NSBundle mainBundle] URLForResource:@"最佳损友" withExtension:@"mp3"],
                       [NSURL URLWithString:@"http://sc1.111ttt.com/2017/4/05/10/298101104389.mp3"]
                       ];
    }
    return _musicArr;
}
-(void)viewDidLoad {
    [super viewDidLoad];
    [LFactory addBackItemForVC:self isPush:YES];
    [self musicArr];
    [self setTableView];
}



-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.bounds];
    self.tableView.rowHeight = ([UIScreen mainScreen].bounds.size.width * 618/480);
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:reuseIdentifier];

    
}

#pragma UITableViewDelegate  Datasource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    cell.textLabel.text = [NSString stringWithFormat:@"音乐%ld",indexPath.row+1];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    AudioPlayerViewController* audioPlayerController = (AudioPlayerViewController*)[[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"AudioPlayerViewController"];
    audioPlayerController.audioPathURL = (NSURL*)[self.musicArr objectAtIndex:indexPath.row];
    NSLog(@"%@",audioPlayerController.audioPathURL);
    [self.navigationController pushViewController:audioPlayerController animated:YES];
    
    return ;
}

@end
