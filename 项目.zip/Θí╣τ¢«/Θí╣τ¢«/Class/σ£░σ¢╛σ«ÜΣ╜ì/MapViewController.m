//
//  ViewController.m
//  Demo03-MKMapView
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "MapViewController.h"
#import <MapKit/MapKit.h>
#import "TRAnnotaion.h"

//SDK

@interface MapViewController ()<MKMapViewDelegate>
@property(nonatomic,strong)MKMapView *mapView;
@property (nonatomic, strong) CLLocationManager *manager;

@end

@implementation MapViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [LFactory addBackItemForVC:self isPush:YES];
    _mapView = [[MKMapView alloc]initWithFrame:self.view.bounds];
    [self.view addSubview:_mapView];
    
    //初始化manager
    self.manager = [CLLocationManager new];
    //征求用户同意(假定同意/Info.plist中key)
    [self.manager requestWhenInUseAuthorization];
    //设置代理
    self.mapView.delegate = self;
    
    //设置不允许旋转
    self.mapView.rotateEnabled = NO;
    //设置地图的显示类型(默认是standard类型)
    self.mapView.mapType = MKMapTypeStandard;
    
    //设定地图属性(开始定位/显示在地图上)
    self.mapView.userTrackingMode = MKUserTrackingModeFollow;
    
    
    [self setTianAnMen];
}
-(void)setTianAnMen
{
    //1.创建自定义大头针模型对象
    TRAnnotaion *annotation = [[TRAnnotaion alloc] init];
    CGFloat latitude = 39.915168;
    CGFloat longitude = 116.403875;
    annotation.coordinate = CLLocationCoordinate2DMake(latitude, longitude);
    annotation.title = @"我是主标题";
    annotation.subtitle = @"我是副标题";
    //3.添加到地图视图
    [self.mapView addAnnotation:annotation];
    
    //设置地图显示的区域(让用户看到哪块区域)
    //跨度
    MKCoordinateSpan span = MKCoordinateSpanMake(0.5, 0.5);
    MKCoordinateRegion region = MKCoordinateRegionMake(annotation.coordinate, span);
    [self.mapView setRegion:region animated:YES];

}

#pragma mark --- MKMapViewDelegate
//已经定位到用户的位置
- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation {
    //设置用户位置两个文本(蓝色圈)
    userLocation.title = @"我是主标题";
    userLocation.subtitle = @"我是副标题";
    
    
    NSLog(@"location:%f, %f", userLocation.location.coordinate.latitude, userLocation.location.coordinate.longitude);
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation {
    //4).把用户位置对应的蓝色圈所在位置排除出去
    if ([annotation isKindOfClass:[MKUserLocation class]]) {
        return nil;
    }
    
    static NSString *identifier = @"annotation";
    //从缓存池中获取一个对象
    MKPinAnnotationView *annotationView = (MKPinAnnotationView *)[self.mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
    //缓存池中如果没有创建对象
    if (!annotationView) {
        annotationView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:identifier];
        //5).设置显示弹出框的属性
        annotationView.canShowCallout = YES;
        //设置颜色(RGB)
        annotationView.pinTintColor = [UIColor purpleColor];
        //设置从天而降的动画
        annotationView.animatesDrop = YES;
        //设置左边和右边辅助视图(accessoryView)
        UIImageView *iv = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];
        iv.image = [UIImage imageNamed:@"videoDefault"];
        annotationView.leftCalloutAccessoryView = iv;
        
//        annotationView.backgroundColor = [UIColor redColor];
    } else {
        //有可重用的大头针视图, 将annotation赋值annotationView
        annotationView.annotation = annotation;
    }
    
    return annotationView;
}







@end
