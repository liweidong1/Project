//
//  PanViewController.m
//  项目
//
//  Created by liweidong on 17/8/1.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "PanViewController.h"

@interface PanViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *iimageView;

@end

@implementation PanViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = LWDColorA(234, 234, 234, 1);
    [LFactory addBackItemForVC:self isPush:YES];
    UIPanGestureRecognizer* panGR=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(pan:)];
    //添加
    [self.view addGestureRecognizer:panGR];
}
-(void)pan:(UIPanGestureRecognizer*)gr
{
    //获取触点相对于self.view的左顶点的绝对坐标值
    CGPoint point=[gr locationInView:self.view];
    
    //获取当前触点相对于手势起始时触点位置的横向及纵向
    //CGPoint tranlation=[gr translationInView:self.view];
    //NSLog(@"%@",NSStringFromCGPoint(tranlation));
    self.iimageView.center=point;
}

@end
