//
//  LCFactory.m
//  LCook
//
//  Created by jun on 16/8/22.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LFactory.h"

@implementation LFactory
+ (void)addBackItemForVC:(UIViewController *)vc isPush:(BOOL)isPush{
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [backBtn setImage:[UIImage imageNamed:@"return"] forState:UIControlStateNormal];
    [backBtn setImage:[UIImage imageNamed:@"return"] forState:UIControlStateHighlighted];
    backBtn.frame = CGRectMake(40, 0, 35, 25);
    [backBtn bk_addEventHandler:^(id sender) {
        if (isPush) {
            [vc.navigationController popViewControllerAnimated:YES];
        }else{
            [vc.navigationController dismissViewControllerAnimated:YES completion:nil];
        }
    } forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
    //配置返回按钮距离屏幕边缘的距离
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceItem.width = -15;
    vc.navigationItem.leftBarButtonItems = @[spaceItem, backItem];
}

+ (void)addSearchItemForVC:(UIViewController *)vc clickedHandler:(void (^)())handler{
    UIButton *seachBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [seachBT setBackgroundImage:[UIImage imageNamed:@"搜索_按下"] forState:UIControlStateNormal];
    [seachBT setBackgroundImage:[UIImage imageNamed:@"搜索_按下"] forState:UIControlStateHighlighted];
    seachBT.frame = CGRectMake(0, 0, 45, 45);
    [seachBT bk_addEventHandler:^(id sender) {
        !handler ?: handler();
    } forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *searchItem = [[UIBarButtonItem alloc] initWithCustomView:seachBT];
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceItem.width = -15;
    vc.navigationItem.rightBarButtonItems =  @[spaceItem, searchItem];
}

+ (void)addSetItemForVC:(UIViewController *)vc clickedHandler:(void (^)())handler
{
    UIButton *setBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [setBT setBackgroundImage:[UIImage imageNamed:@"set"] forState:UIControlStateNormal];
    [setBT setBackgroundImage:[UIImage imageNamed:@"set"] forState:UIControlStateHighlighted];
    setBT.frame = CGRectMake(40, 0, 25, 25);
    [setBT bk_addEventHandler:^(id sender) {
        !handler ?: handler();
    } forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *setItem = [[UIBarButtonItem alloc] initWithCustomView:setBT];
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceItem.width = 15;
    vc.navigationItem.leftBarButtonItems =  @[spaceItem, setItem];

}

+ (void)addLeftSearchItemForVC:(UIViewController *)vc clickedHandler:(void (^)())handler{
    UIButton *seachBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [seachBT setBackgroundImage:[UIImage imageNamed:@"搜索_默认"] forState:UIControlStateNormal];
    [seachBT setBackgroundImage:[UIImage imageNamed:@"搜索_按下"] forState:UIControlStateHighlighted];
    seachBT.frame = CGRectMake(0, 0, 45, 45);
    [seachBT bk_addEventHandler:^(id sender) {
        !handler ?: handler();
    } forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *searchItem = [[UIBarButtonItem alloc] initWithCustomView:seachBT];
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceItem.width = -15;
    vc.navigationItem.leftBarButtonItems =  @[spaceItem, searchItem];
}
+ (void)addTopItemForVC:(UIViewController *)vc clickedHandler:(void (^)())handler{
    UIButton *seachBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [seachBT setBackgroundImage:[UIImage imageNamed:@"head_crown_24x24"] forState:UIControlStateNormal];
    [seachBT setBackgroundImage:[UIImage imageNamed:@"head_crown_24x24"] forState:UIControlStateHighlighted];
    seachBT.frame = CGRectMake(0, 0, 30, 30);
    [seachBT bk_addEventHandler:^(id sender) {
        !handler ?: handler();
    } forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *searchItem = [[UIBarButtonItem alloc] initWithCustomView:seachBT];
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceItem.width = -15;
    vc.navigationItem.rightBarButtonItems =  @[spaceItem, searchItem];
}
@end
