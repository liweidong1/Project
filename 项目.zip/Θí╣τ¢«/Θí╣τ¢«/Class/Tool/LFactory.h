//
//  LCFactory.h
//  LCook
//
//  Created by jun on 16/8/22.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LFactory : NSObject
//自动为传入的参数拼装上返回按钮
+ (void)addBackItemForVC:(UIViewController *)vc isPush:(BOOL)isPush;
//添加右侧搜索按钮
+ (void)addSearchItemForVC:(UIViewController *)vc clickedHandler:(void(^)())handler;
+ (void)addSetItemForVC:(UIViewController *)vc clickedHandler:(void(^)())handler;


//添加左侧搜索按钮
+ (void)addLeftSearchItemForVC:(UIViewController *)vc clickedHandler:(void(^)())handler;
//右侧排行
+ (void)addTopItemForVC:(UIViewController *)vc clickedHandler:(void(^)())handler;





@end
