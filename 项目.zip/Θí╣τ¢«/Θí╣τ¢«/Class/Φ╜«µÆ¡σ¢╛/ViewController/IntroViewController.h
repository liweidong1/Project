//
//  IntroViewController.h
//  GameLive
//  推荐页(前三页中最难一页)
//  Created by tarena on 16/7/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IntroViewController : UICollectionViewController

@end
