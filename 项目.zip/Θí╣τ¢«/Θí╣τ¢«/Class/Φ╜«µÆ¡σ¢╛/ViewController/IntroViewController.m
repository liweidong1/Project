//
//  IntroViewController.m
//  GameLive
//
//  Created by tarena on 16/7/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "IntroViewController.h"
#import "TRAdCell.h"
#import "TRIntroViewModel.h"


#import "MoviePlayerViewController.h"
//@import AVKit;
//@import AVFoundation;

@interface IntroViewController ()<UICollectionViewDelegateFlowLayout, TRAdCellDelegate, TRAdCellDataSource>
@property (nonatomic) TRIntroViewModel *introVM;
@end

@implementation IntroViewController
#pragma mark - TRAdCell Delegate
- (NSInteger)numberOfItemsInCell:(TRAdCell *)cell{
    return self.introVM.indexNum;
}
- (NSURL *)iconURLForItemInCell:(TRAdCell *)cell atIndex:(NSInteger)index{
    return [self.introVM indexIconURLForRow:index];
}
- (void)adCell:(TRAdCell *)cell didSelectedIconAtIndex:(NSInteger)index{
//    AVPlayerViewController *vc = [AVPlayerViewController new];
//    vc.player = [AVPlayer playerWithURL:[self.introVM videoURLForRow:index]];
//    [self.navigationController pushViewController:vc animated:YES];
//    [vc.player play];
    
    MoviePlayerViewController *movie = [[MoviePlayerViewController alloc]init];
    NSURL *URL                       = [self.introVM videoURLForRow:index];
    movie.videoURL                   = URL;
    
    self.navigationController.navigationBar.hidden = YES;
    [self.navigationController pushViewController:movie animated:YES];

}
- (NSString *)titleForItemInCell:(TRAdCell *)cell atIndex:(NSInteger)index{
    return [self.introVM indexTitleForRow:index];
}

#pragma mark - LifeCycle 生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    [LFactory addBackItemForVC:self isPush:YES];
    self.collectionView.backgroundColor = LWDColorA(234, 234, 234, 1);
    [self.collectionView registerClass:[TRAdCell class] forCellWithReuseIdentifier:@"TRAdCell"];
    
    __weak typeof(self) weakSelf = self;
    [self.collectionView addHeaderRefresh:^{
        [weakSelf.introVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf.collectionView endHeaderRefresh];
            [weakSelf.collectionView reloadData];
        }];
    }];
    
    [self.collectionView beginHeaderRefresh];
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = NO;
}
#pragma mark - UICollectionView Delegate
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsZero;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            //720 * 400
            return CGSizeMake(kScreenW, kScreenW * 400 / 720);
        }
    }
    return CGSizeZero;
}


- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1; //暂时先写一个
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 1; //暂时先写一个, 然后慢慢添加
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            TRAdCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"TRAdCell" forIndexPath:indexPath];
            cell.dataSource = self;
            cell.delegate = self;
            [cell reloadData];
            return cell;
        }
    }
    return nil;
}


#pragma mark - LazyLoad 懒加载
- (TRIntroViewModel *)introVM {
	if(_introVM == nil) {
		_introVM = [[TRIntroViewModel alloc] init];
	}
	return _introVM;
}

@end
