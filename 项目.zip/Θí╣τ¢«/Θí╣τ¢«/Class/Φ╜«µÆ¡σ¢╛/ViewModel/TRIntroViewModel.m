//
//  TRIntroViewModel.m
//  GameLive
//
//  Created by tarena on 16/8/1.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "TRIntroViewModel.h"

@implementation TRIntroViewModel

- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler{
    self.dataTask = [TRNetManager getIntroCompletionHandler:^(TRIntroModel *model, NSError *error) {
        if (!error) {
            _indexList = model.mobileIndex;
        }
        !completionHandler ?: completionHandler(error);
    }];
}

- (NSInteger)indexNum{
    return self.indexList.count;
}
- (NSURL *)indexIconURLForRow:(NSInteger)row{
    return self.indexList[row].linkObject.thumb.yx_URL;
}
- (NSString *)indexTitleForRow:(NSInteger)row{
    return self.indexList[row].linkObject.title;
}
- (NSURL *)videoURLForRow:(NSInteger)row{
    return self.indexList[row].linkObject.uid.yx_VideoURL;
}





@end
