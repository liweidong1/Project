//
//  TRIntroViewModel.h
//  GameLive
//
//  Created by tarena on 16/8/1.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "TRNetManager.h"

@interface TRIntroViewModel : BaseViewModel
/*********  头部滚动广告栏  ***********/
@property (nonatomic) NSArray<TRIntroMobileModel *> *indexList;
@property (nonatomic, readonly) NSInteger indexNum;
- (NSURL *)indexIconURLForRow:(NSInteger)row;
- (NSString *)indexTitleForRow:(NSInteger)row;
- (NSURL *)videoURLForRow:(NSInteger)row;


/*********  头部滚动主播展示栏   ***********/

/*********  精彩推荐    *************/

/*********  其他页面    ************/


@end
