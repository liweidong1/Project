//
//  AppDelegate.m
//  项目
//
//  Created by liweidong on 17/8/1.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate

#pragma mark - 远程推送服务协议
-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    
}
//启动后立即触发,,返回的是当前设备在苹果服务器上的唯一标识
-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    
}
-(void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.rootViewController = [[UINavigationController alloc]initWithRootViewController:[ViewController new]];
    [self.window makeKeyAndVisible];
    
    
    
    
    
#warning 推送服务需要获取用户的许可才可以,需要在程序启东时获取用户的许可,ios8之前和之后获取许可的代码不同
    NSInteger version =[UIDevice currentDevice].systemVersion.floatValue;
    if (version < 8.0) {
        [application registerForRemoteNotificationTypes:UIRemoteNotificationTypeSound |
         UIRemoteNotificationTypeAlert |
         UIRemoteNotificationTypeBadge];
    }else { //  >=8.0
        UIUserNotificationSettings * settings = [UIUserNotificationSettings settingsForTypes:UIRemoteNotificationTypeSound| UIRemoteNotificationTypeAlert |
                                                 UIRemoteNotificationTypeBadge categories:nil];
        [application registerUserNotificationSettings:settings];
        //[application registerUserNotificationSettings:settings];
        
    }
    //1创建本地通知
    UILocalNotification * localNoti =[UILocalNotification new];
    //设置提示内容
    localNoti.alertBody = @"alertBody";
    //设置操作提示
    localNoti.alertAction = @"解锁";
    //设置推送的提示音,MP3格式,小于30秒
    localNoti.soundName = @"lingsheng.mp3";
    //设置图标上的数字
    localNoti.applicationIconBadgeNumber = 9;
    
    //安排当前时间10秒钟以后触发此操作
    localNoti.fireDate = [[NSDate date]dateByAddingTimeInterval:10];
    //安排通知操作
    [application scheduleLocalNotification:localNoti];
    //运行--->按cmd+L 锁频,,等10秒钟,打开电脑声音
    return YES;
}


#warning 下方协议方法会在推送消息被点击(桌面从屏幕上方弹出消息)(锁屏)右滑打开,当前消息就在前台时触发
-(void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    NSLog(@"notification %@",notification);
}
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}
//当应用程序被点击显示在前台,把图片上的数字去掉
- (void)applicationWillEnterForeground:(UIApplication *)application {
    application.applicationIconBadgeNumber = 0;
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
