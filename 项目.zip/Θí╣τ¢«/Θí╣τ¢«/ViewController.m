//
//  ViewController.m
//  项目
//
//  Created by liweidong on 17/8/1.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "ViewController.h"
#import "MoviePlayerViewController.h"     //播放器
#import "IntroViewController.h"           //轮播图
#import "TwoListViewController.h"         //单视图，多列表
#import "BeautiViewController.h"          //瀑布流
#import "ListViewController.h"            //cell自适应
#import "MapViewController.h"             //原生定位
#import "PanViewController.h"             //拖拽
#import "AudioListViewController.h"  //音乐播放器

#import "GetFilePath.h"


@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,UINavigationControllerDelegate, UIImagePickerControllerDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSArray *listArr;
@end
static NSString * const reuseIdentifier = @"Cell";
@implementation ViewController
- (NSArray *)listArr {
    if(_listArr == nil) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"list" ofType:@"plist"];
        _listArr =  [NSArray arrayWithContentsOfFile:path];
    }
    return _listArr;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self listArr];
    
    self.navigationItem.title = @"大厅";
    
    
    [self setTableView];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = NO;
}

-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.bounds];
    self.tableView.rowHeight = ([UIScreen mainScreen].bounds.size.width * 618/480);
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:reuseIdentifier];
    

    self.tableView.tableFooterView = [UIView new];
//    [self loadDatas];
    
}

#pragma UITableViewDelegate  Datasource
//- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//    return 10;
//}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    cell.textLabel.text = _listArr[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        MoviePlayerViewController *movie = [[MoviePlayerViewController alloc]init];
        NSURL *URL                       = [NSURL URLWithString:@"https://bmob-cdn-11424.b0.upaiyun.com/2017/07/28/11455c1d6a674b3488144cf701a0ca8f.mp4"];
        movie.videoURL                   = URL;
        
        self.navigationController.navigationBar.hidden = YES;
        [self.navigationController pushViewController:movie animated:YES];

    }else if(indexPath.row == 1){
        IntroViewController *introVC = [[IntroViewController alloc] initWithCollectionViewLayout:[UICollectionViewFlowLayout new]];
        [self.navigationController pushViewController:introVC animated:YES];
    }else if(indexPath.row == 2){
        TwoListViewController *twoListVC = [[TwoListViewController alloc]init];
        [self.navigationController pushViewController:twoListVC animated:YES];
    }else if(indexPath.row == 3){
        BeautiViewController *vc = [[BeautiViewController alloc] initWithCollectionViewLayout:[CHTCollectionViewWaterfallLayout new]];
        [self.navigationController pushViewController:vc animated:YES];
    }else if(indexPath.row == 4){
        ListViewController *listVC = [[ListViewController alloc]init];
        [self.navigationController pushViewController:listVC animated:YES];
    }else if(indexPath.row == 5){
        MapViewController *mapVC = [[MapViewController alloc]init];
        [self.navigationController pushViewController:mapVC animated:YES];
    }else if(indexPath.row == 6){
        PanViewController *pan = [[PanViewController alloc]init];
        [self.navigationController pushViewController:pan animated:YES];
    }else if(indexPath.row == 7){
        //本地通知
    }else if(indexPath.row == 8){
        [self  recordBtnClick];
    }else {
        AudioListViewController *audioListVC = [[AudioListViewController alloc]init];
        [self.navigationController pushViewController:audioListVC  animated:YES];
    }
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5;
}

/**
 *  录制视频相关
 */
-(void)recordBtnClick
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        picker.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeCamera];
        picker.videoQuality = UIImagePickerControllerQualityTypeMedium; //录像质量
        picker.videoMaximumDuration = 15.0f; //录像最长时间
        picker.mediaTypes = [NSArray arrayWithObjects:@"public.movie", nil];
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"当前设备不支持录像功能" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];
    }
    //跳转到拍摄页面
    [self presentViewController:picker animated:YES completion:nil];
    
}
#pragma -mark ---隐藏navigation tabbar 电池栏
- (void)toolbarHidden:(BOOL)Bool{
    self.navigationController.navigationBar.hidden = Bool;
    self.tabBarController.tabBar.hidden = Bool;
    [[UIApplication sharedApplication] setStatusBarHidden:Bool withAnimation:UIStatusBarAnimationFade];
}
//拍摄协议
#pragma -mark ---拍摄完成后要执行的代理方法
// chose选中某张图片,内含参数info,图片的信息.(选中后调用此方法)
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    //保存拍摄视频
    NSString *mediaType = [info objectForKey:UIImagePickerControllerMediaType];
    BOOL success;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if ([mediaType isEqualToString:@"public.movie"]) {
        NSString *videoPath = [GetFilePath getSavePathWithFileSuffix:@"mov"];
        success = [fileManager fileExistsAtPath:videoPath];
        if (success) {
            [fileManager removeItemAtPath:videoPath error:nil];
        }
        
        NSURL *videoURL = [info objectForKey:UIImagePickerControllerMediaURL];
        
        //将拍摄的视频存入相册
                UISaveVideoAtPathToSavedPhotosAlbum(videoPath, self, nil, nil);//将拍摄的视频存入相册
        
        
        NSData *videlData = [NSData dataWithContentsOfURL:videoURL];
        NSLog(@"--------data.length=%lu",(unsigned long)videlData.length);
        [videlData writeToFile:videoPath atomically:YES]; //写入本地
        //存储数据
        success = [fileManager fileExistsAtPath:videoPath];
        if (success) {
            NSLog(@"media 写入成功,video路径:%@",videoPath);
        }
        NSLog(@"拍摄完毕！！！:%@",info[UIImagePickerControllerMediaURL]);
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}
#pragma -mark ---进入拍摄页面点击取消按钮
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"点击了取消按钮！！！");
    [self dismissViewControllerAnimated:YES completion:nil];
}




@end
